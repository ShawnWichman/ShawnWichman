
var newArray = [];
for(var i = 1; i <= 255; i++){
    newArray.push(i);
}
console.log(newArray); 



sum = 0; 
for (num = 1; num <= 1000; num++) { 
	if (num % 2 ==0) { 
		sum += num; 
	} 
} 
console.log(sum); 








