for (var x=1; x<20; x++){
    if (x%2==0){
        x++;
    }
    else if(x%2>0){
    } 
    console.log(x)}




var num = 1; 
var sum=1   
while (num <= 5) {        
    console.log(num);
    console.log (sum)
    num=num+1;
    sum= sum+num
    
}

      
