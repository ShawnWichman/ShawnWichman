var testArr = [6,3,5,1,2,4]
sum=0

for (var i=0; i<testArr.length; i++){
    sum = testArr[i]+sum
    console.log(testArr[i])
    console.log(sum)
}



